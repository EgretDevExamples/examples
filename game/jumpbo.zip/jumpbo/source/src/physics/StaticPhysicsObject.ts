module physics
{
	export class StaticPhysicsObject extends SimplePhysicsObject{
		
		public constructor(width:number, height:number) {
			super(width, height);
		}
		
	}
}




