﻿module game {

    export interface IUpdate {

        OnUpdate(time:number): void;
    }


}  