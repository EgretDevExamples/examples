﻿module game {

    export interface IObject extends game.ILoad,game.IUpdate {

        ID: number;

    }

} 