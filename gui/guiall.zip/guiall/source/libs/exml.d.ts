declare module screenContentSkins{
	class AlertScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class BitmapLabelScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class ButtonScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class DropDownListScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class LabelScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class LayoutScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class ListCustomScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class ListScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class PanelScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class ProgressBarScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class ScrollerScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class SliderScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class TabBarScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class TitleWindowScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class TogglesScreenSkin extends egret.gui.Skin{
	}
}
declare module screenContentSkins{
	class TreeScreenSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class AlertSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class ButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class CheckBoxSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class CustomItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class DropDownListItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class DropDownListOpenButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class DropDownListSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class HSliderSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class HSliderThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class ItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class ListSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class PanelSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class ProgressBarSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class RadioButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class ScreenItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class SkinnableContainerSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class SliderThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class TabBarButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class TabBarSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class TitleWindowSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class ToggleButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class ToggleSwitchSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class TreeDisclosureButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class TreeItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class TreeSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class VProgressBarSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class VSliderSkin extends egret.gui.Skin{
	}
}
declare module skins.ocean{
	class VSliderThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class AlertSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class CheckBoxSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class CloseButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class CustomItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class DropDownListItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class DropDownListOpenButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class DropDownListSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class HSliderSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class HSliderThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ListSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class PanelSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ProgressBarSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class RadioButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class SkinnableContainerSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class SliderThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TabBarButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TabBarSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TitleWindowSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ToggleButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ToggleSwitchSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TreeDisclosureButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TreeItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TreeSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class VProgressBarSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class VSliderSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class VSliderThumbSkin extends egret.gui.Skin{
	}
}
