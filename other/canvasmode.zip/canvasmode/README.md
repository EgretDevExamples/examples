﻿# examples


示例的宽高 800*600

--------------------------

#分类

dragonbones 龙骨相关

feather 粒子相关

game 游戏相关

gui UI组件

net 网络相关

p2 物理相关

sound 声音相关

text 文字相关

tweens 缓动相关

-------------------------------

#创建 目录结构可参考（test/helloword）

在相关目录建立文件夹，内容包含示例代码与一个README，README填写重要代码片段

文件夹（例如 helloword）

   --- 源代码（source） launcher libs resource src egretProperties

   --- 发布版本（release）launcher resource index
   
   --- README.md 重要代码片段
   
   --- 一张图片400*300 封面图（logo.png）

