require("launcher/native_require.js");

egret_native.egtMain = function () {
    egret_native.egretInit();

    egret_native.loadVersion(egret_native.egretStart);
};
